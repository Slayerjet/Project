<footer>
    &copy; Video Game Home Surveys 2018 Sean Cronk | <a href="tel:07867 936126">Call us: 07867 936126</a> | <a class="terms" href="javascript:alert('Terms and Conditions Bla Bla Bla')">Term &amp; Conditions</a>
</footer>

</body>

</html>
