<?php

//set the title for the page
$title = 'VGHS - Games';
include 'header.php';
?>
                    

    <br>
    <br>
    <aside>
        <article class="mainPage">
            <h3>Games</h3>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
        </article>
    </aside>
    
<?php
    include 'footer.php';
?>
